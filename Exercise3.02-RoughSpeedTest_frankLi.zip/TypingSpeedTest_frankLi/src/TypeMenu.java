import javax.swing.*;
import javax.swing.text.*;
import java.awt.event.*;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;

/**
 * This frame will provide a graphical user interface (GUI) of the start menu, 
 * and it can open the translator class.
 * @author Frank Li
 * @date  November 18, 2018
 */
public class TypeMenu extends JFrame implements ActionListener, KeyListener
{
        private JFrame startFrame;
        private JTextField txtTypeYourWords;
        private JTextPane textPane;
        private JPanel mainPanel, keyboardPanel;
        private JButton[] keys;
        private JButton backspace, tab, caps, enter, lShift, rShift, spacebar;
        private char[] correctChars;
        private ArrayList<String> typedWords = new ArrayList<String>();
        private JToggleButton keyboard;
        public boolean keyboardOn;
        private StyledDocument doc;
        private Style correct, incorrect;
        private String qwerty = "`1234567890-=qwertyuiop[]\\asdfghjkl;'zxcvbnm,./ ";
        private String QWERTY = "~!@#$%^&*()_+QWERTYUIOP{}|ASDFGHJKL:\"ZXCVBNM<>? ";
        private String text = "", prevWord;
        int minute = 60, currentChar = 0, numOfWords = 0;
        Timer time;
	/**
	 * Constructor method sets up the frame for the start menu 
	 * graphical user interface
	 */

	public TypeMenu()
	{
		mainPanel = new JPanel();
		mainPanel.setBounds(0, 0, 879, 1050);
		mainPanel.setForeground(Color.WHITE);
		mainPanel.setBackground(new Color(238, 232, 170));
		mainPanel.setLayout(null);
		
		textPane = new JTextPane();
		textPane.setEditable(false);
		textPane.setFont(new Font("Arial", Font.PLAIN, 30));
		textPane.setBounds(63, 266, 755, 282);
		mainPanel.add(textPane);
		//https://stackoverflow.com/questions/3213045/centering-text-in-a-jtextarea-or-jtextpane-horizontal-text-alignment
		doc = textPane.getStyledDocument();
		SimpleAttributeSet center = new SimpleAttributeSet();
    	correct = textPane.addStyle("Green", null);
    	incorrect = textPane.addStyle("Red", null);
    	StyleConstants.setForeground(correct, Color.BLUE);
    	StyleConstants.setForeground(incorrect, Color.RED);
		StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
		doc.setParagraphAttributes(0, doc.getLength(), center, false);
		

    	
		
		try {
			IO.openInputFile("quickBrownFox.txt");
			String line = IO.readLine();
			
			while (line != null) //read out poem
			{
				text += line;
				line = IO.readLine();
			}
			IO.closeInputFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		textPane.setText(text);
		correctChars = text.toCharArray();
		System.out.println(correctChars);

		
		txtTypeYourWords = new JTextField();
		txtTypeYourWords.setFont(new Font("Arial", Font.PLAIN, 30));
		txtTypeYourWords.setHorizontalAlignment(SwingConstants.CENTER);
		txtTypeYourWords.setText("Type your words here");
		txtTypeYourWords.setBounds(63, 549, 755, 60);
		txtTypeYourWords.addKeyListener(this); 
		mainPanel.add(txtTypeYourWords);
		txtTypeYourWords.setColumns(10);		
		
		JLabel lblTypingSpeedTest = new JLabel("TYPING SPEED TEST");
		lblTypingSpeedTest.setForeground(new Color(250, 128, 114));
		lblTypingSpeedTest.setFont(new Font("Faster One", Font.PLAIN, 60));
		lblTypingSpeedTest.setHorizontalAlignment(SwingConstants.CENTER);
		lblTypingSpeedTest.setBounds(63, 32, 755, 60);
		mainPanel.add(lblTypingSpeedTest);
		
		JLabel lblWantToSee = new JLabel("Want to see how fast you can type?");
		lblWantToSee.setHorizontalAlignment(SwingConstants.CENTER);
		lblWantToSee.setFont(new Font("Arial", Font.PLAIN, 20));
		lblWantToSee.setBounds(177, 108, 514, 60);
		mainPanel.add(lblWantToSee);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setBounds(218, 227, 84, 29);
		mainPanel.add(lblNewLabel);
		
		JButton btnRestart = new JButton("Restart");
		btnRestart.setBounds(648, 227, 115, 29);
		mainPanel.add(btnRestart);
		
		JLabel lblTime = new JLabel("Time: 60");
		lblTime.setFont(new Font("Arial", Font.PLAIN, 20));
		lblTime.setBounds(540, 231, 93, 20);
		mainPanel.add(lblTime);
		
		JLabel CPM = new JLabel("CPM:");
		CPM.setBounds(180, 231, 69, 20);
		mainPanel.add(CPM);
		
		JLabel WPM = new JLabel("WPM:");
		WPM.setBounds(355, 230, 69, 20);
		mainPanel.add(WPM);
		
		JLabel label = new JLabel("New label");
		label.setBounds(400, 227, 84, 29);
		mainPanel.add(label);
		
		keyboard = new JToggleButton("Keyboard");
		keyboard.addItemListener(new ItemListener() {
			   public void itemStateChanged(ItemEvent ev) {
			      if(ev.getStateChange()==ItemEvent.SELECTED){
			    	  keyboardPanel.setVisible(true);
			    	  addButtons();
			    	  keyboardOn = true;
			      } else if(ev.getStateChange()==ItemEvent.DESELECTED){
			        keyboardPanel.setVisible(false);
			        keyboardOn = false;
			      }
			   }
			});
		keyboard.setBounds(355, 619, 163, 29);
		mainPanel.add(keyboard);
        keyboardPanel = new JPanel();
        keyboardPanel.setBounds(0, 691, 878, 312);
        keyboardPanel.setVisible(false);
        mainPanel.add(keyboardPanel);
        keyboardPanel.setLayout(null);
		
		//Set up the Jframe
		startFrame = new JFrame("Typing Speed Test");
        startFrame.setSize(900, 1075);
        startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startFrame.getContentPane().add(mainPanel);
		startFrame.setVisible(true);
		
		time = new Timer (1000, new ActionListener() {
		     public void actionPerformed(ActionEvent evt) {
		    	 minute--;
				    if(minute == 0) //when seconds is equal to 60 then reset it to 0 and add to minutes
				    {
				    	time.stop();
				    	minute = 60;
				    	startFrame.dispose();
				    }
				    else { //until seconds is equal to 60 then prints seconds
				    	if (minute < 10) //added to make it look better, adds a 0 in front until this time is over 10
				    		lblTime.setText("Time: 0" + minute);
				    	else
				    		lblTime.setText("Time:" + minute); 	
				    }  	
		      }
		  });
	} 
  
	public void addButtons() {
		keys = new JButton[qwerty.length()];
		
        for (int i = 0; i < qwerty.length()-1; i++) {
            keys[i] = new JButton("" + qwerty.charAt(i));
            // new Integer('a' + i).toString()
            keys[i].setSize(60, 60);
            setPosition(i);
            keyboardPanel.add(keys[i]);
        }   
            spacebar = new JButton();
            keys[qwerty.length()-1] = spacebar;
            spacebar.setSize(300, 60);
            spacebar.setLocation(235, 240);
            keyboardPanel.add(spacebar);  
            
            backspace = new JButton("Backspace");
            backspace.setSize(98, 60);
            backspace.setLocation(780, 0);
            keyboardPanel.add(backspace); 
            
            tab = new JButton("Tab");
            tab.setSize(95, 60);
            tab.setLocation(0, 60);
            keyboardPanel.add(tab);  
            
            caps = new JButton("Caps Lock");
            caps.setSize(105, 60);
            caps.setLocation(0, 120);
            keyboardPanel.add(caps); 
           
            enter = new JButton("Enter");
            enter.setSize(113, 60);
            enter.setLocation(765, 120);
            keyboardPanel.add(enter);
            
            lShift = new JButton("lShift");
            lShift.setSize(115, 60);
            lShift.setLocation(0, 180);
            keyboardPanel.add(lShift); 
            
            rShift = new JButton("rShift");
            rShift.setSize(163, 60);
            rShift.setLocation(715, 180);
            keyboardPanel.add(rShift); 
    }
	
	public void setPosition(int i) {
        if (i <= 12) 
        	keys[i].setLocation(0 + 60*i, 0); 
        else if (i >= 13 && i < 26)
        	keys[i].setLocation(95 + 60*(i - 13), 60);
        else if (i >= 26 && i < 37) 
            keys[i].setLocation(105 + 60*(i-26), 120);
        else if (i >= 37) 
            keys[i].setLocation(115 + 60*(i-37), 180);
    }	
	
	public static void main(String[] args)
	{
		TypeMenu gui = new TypeMenu(); //open up the start menu
	}


	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

    public void keyPressed (KeyEvent e) {
    	//time.start();
        if (e.getKeyCode() == KeyEvent.VK_BACK_SPACE && numOfWords > 0 && txtTypeYourWords.getText().isEmpty()) {
    		numOfWords--; //this doesn't work

        	txtTypeYourWords.setText(typedWords.get(numOfWords) + " ");
        	System.out.println(numOfWords);
        }
    	try {
        int i = qwerty.indexOf(e.getKeyChar());
        int c = QWERTY.indexOf(e.getKeyChar());
        if (i > 0)
        	keys[i].setBackground(Color.GREEN);
        else
        	keys[c].setBackground(Color.GREEN);
    	} catch (Exception d) {
    		
    	if (keyboardOn == true)	{
    	switch(e.getKeyCode()) {
    		case KeyEvent.VK_ENTER: enter.setBackground(Color.GREEN);
    		break;
    		case KeyEvent.VK_BACK_SPACE: backspace.setBackground(Color.GREEN);
    		break;
    		case KeyEvent.VK_TAB: tab.setBackground(Color.GREEN);
    		break;
    		case KeyEvent.VK_SHIFT: lShift.setBackground(Color.GREEN);
    		rShift.setBackground(Color.GREEN);
    		break;
    		case KeyEvent.VK_CAPS_LOCK: caps.setBackground(Color.GREEN);
    		break;
    		default: break;
    	}
    	}
    	}
    }

    public void keyReleased (KeyEvent e) {
        if (e.getKeyChar() == ' ') {
        	 
        	if (txtTypeYourWords.getText() != prevWord) { //this doesn't work correctly! fix this frank
        	typedWords.add(txtTypeYourWords.getText().replaceAll(" ", ""));
        	prevWord = txtTypeYourWords.getText().replaceAll(" ", "");
        	}
        	System.out.println(numOfWords + prevWord);
        	numOfWords++;
        	txtTypeYourWords.setText(null);
        }
        
    	try {
        int i = qwerty.indexOf(e.getKeyChar());
        int c = QWERTY.indexOf(e.getKeyChar());
        if (i > 0)
        	keys[i].setBackground(null);
        else
        	keys[c].setBackground(null);
    	} catch (Exception d) {
    		
    	if (keyboardOn == true) {	
    	switch(e.getKeyCode()) {
    		case KeyEvent.VK_ENTER: enter.setBackground(null);
    		txtTypeYourWords.setText("");
    		break;
    		case KeyEvent.VK_BACK_SPACE: backspace.setBackground(null);
    		break;
    		case KeyEvent.VK_TAB: tab.setBackground(null);
    		break;
    		case KeyEvent.VK_SHIFT: lShift.setBackground(null);
    		rShift.setBackground(null);
    		break;
    		case KeyEvent.VK_CAPS_LOCK: caps.setBackground(null);
    		break;
    		default: break;
    	}
    	}
    	
    	}
    }

	@Override
	public void keyTyped(KeyEvent e) {
		
		if (e.getKeyChar() == (KeyEvent.VK_BACK_SPACE) && currentChar > 0) {
			currentChar--; //this doesn't work
			System.out.println(correctChars[currentChar]);
		}
		else if (e.getKeyChar() == ' ') {
			currentChar++;
		}
		else {
			
	        if (e.getKeyChar() == correctChars[currentChar]) {
	        	doc.setCharacterAttributes(currentChar, 1, correct, true); 
	        	currentChar++;
	            
	        }
	        else if (e.getKeyChar() != correctChars[currentChar]) {
	        	doc.setCharacterAttributes(currentChar, 1, incorrect, true); 
	        	currentChar++;
	        	
	        }
		}
      
	}
} // end class